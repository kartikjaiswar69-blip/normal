const cat = document.getElementById("cat");

let isDragging = false;
let offsetX, offsetY;

// 🖱️ Mouse Events
cat.addEventListener("mousedown", (e) => {
  isDragging = true;
  cat.classList.add("fly"); // switch to flying cat gif
  offsetX = e.clientX - cat.offsetLeft;
  offsetY = e.clientY - cat.offsetTop;
});

document.addEventListener("mousemove", (e) => {
  if (isDragging) {
    cat.style.left = e.clientX - offsetX + "px";
    cat.style.top = e.clientY - offsetY + "px";
  }
});

document.addEventListener("mouseup", () => {
  isDragging = false;
  cat.classList.remove("fly"); // back to idle cat gif
});

// 📱 Touch Events (for mobile)
cat.addEventListener("touchstart", (e) => {
  isDragging = true;
  cat.classList.add("fly");
  let touch = e.touches[0];
  offsetX = touch.clientX - cat.offsetLeft;
  offsetY = touch.clientY - cat.offsetTop;
});

document.addEventListener("touchmove", (e) => {
  if (isDragging) {
    let touch = e.touches[0];
    cat.style.left = touch.clientX - offsetX + "px";
    cat.style.top = touch.clientY - offsetY + "px";
  }
});

document.addEventListener("touchend", () => {
  isDragging = false;
  cat.classList.remove("fly");
});
